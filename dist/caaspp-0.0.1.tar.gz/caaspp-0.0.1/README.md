# CAASPP

An unofficial API for CAASPP websites.

## Installation:
`pip install git+https://github.com/GitPushPullLegs/caaspp.git`